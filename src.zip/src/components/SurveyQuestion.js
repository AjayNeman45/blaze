import React from "react";

const SurveyQuestion = () => {
  return (
    <div>
      <h2>GDPR consent</h2>
      <p>EU-based respondent terminated when they did not consent to GDPR</p>
    </div>
  );
};

export default SurveyQuestion;
