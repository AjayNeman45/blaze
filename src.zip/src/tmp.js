export const data = [
  {
    company_email: "himal.saifi@irbureau.com",
    supply_managers: [
      {
        email: "john@gmail.com",
        name: "john doe",
        phone: 462422645,
      },
    ],
    company_name: "IRB LLC",
    id: 10000000,
    project_managers: [
      {
        name: "john smith",
        email: "smith@gmail.com",
        phone: 988845753,
      },
    ],
    account_managers: [
      {
        name: "himal safai",
        email: "himal.saifi@irbureau.com",
        phone: 4252442525,
      },
    ],
  },
  {
    company_name: "Centico Research",
    project_managers: [
      {
        phone: 8987678953,
        email: "janhavi@gmail.com",
        name: "janhavi rajput",
      },
      {
        phone: "9876543211",
        email: "abc@gmail.com",
        name: "abc",
      },
    ],
    account_managers: [
      {
        name: "kajal sharma",
        phone: 454747464,
        email: "kajal@sharma.com",
      },
    ],
    supply_managers: [
      {
        email: "varsha@gmail.com",
        name: "varsha jadhav",
        phone: 6745745755,
      },
    ],
    company_email: "centicoresearch.com",
  },
  {
    company_email: "robasresearch",
    account_managers: [
      {
        phone: 865856845,
        email: "lokesh@rahul.com",
        name: "lokesh rahul",
      },
    ],
    supply_managers: [
      {
        name: "sonu shrivastava",
        phone: 84784574,
        email: "sonu@gmail.com",
      },
    ],
    company_name: "Robas Research",
    project_managers: [
      {
        email: "sagar@gmail.com",
        phone: 457457454,
        name: "sagar borude",
      },
    ],
  },
  {
    company_name: "Research World Panel",
    company_email: "Research World Panel",
  },
  {
    company_name: "Market Cube (Schlesinger Group)",
  },
  {
    company_name: "Team Vizory",
  },
  {
    company_name: "Rakuten Insights",
  },
  {
    company_name: "Philomath Research",
  },
  {
    company_name: "Market Xcel",
  },
  {
    company_name: "iMad Research",
  },
  {
    company_name: "GMO Research",
  },
  {
    company_name: "EA Response",
  },
  {
    company_name: "Track Opinion",
  },
  {
    company_name: "RMR",
  },
  {
    company_name: "Adept Research",
  },
];
