import React from "react";
import { FaInfoCircle } from "react-icons/fa";
import Header from "../../components/header/Header";
import Subheader from "../../components/subheader/Subheader";
import styles from "./Allocations.module.css";
import { useAllocationContext } from "./AllocationContext";
import { BiChevronDown } from "react-icons/bi";
import Snackbar from "@mui/material/Snackbar";
import MuiAlert from "@mui/material/Alert";
import SurveyInfo from "../../components/survey-info/SurveyInfo";
import { AiOutlinePlusCircle } from "react-icons/ai";
import AddSupplierModal from "./AddSupplierModal";
import InternalSupplierModal from "./InternalSupplierModal";
import { v4 as uuid } from "uuid";
import AddStaticRedirectsModal from "./AddStaticRedirectsModal";
import SnackbarMsg from "../../components/Snackbar";

const Alert = React.forwardRef(function Alert(props, ref) {
  return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
});

const Allocations = () => {
  const {
    externalSuppliers,
    internalSuppliers,
    setSupplierModal,
    handleInternalSupplierModal,
    supplierModal,
    openSnackbar,
    handleSnackbar,
    internalsupplierModal,
    staticRedirectsModal,
    setStaticRedirectsModal,
    snackbarData,
    survey,
  } = useAllocationContext();
  return (
    <>
      <Header />
      <Subheader />
      <div>
        <SurveyInfo />
        {/* <ProjectInfo surveyStatus={survey?.status} /> */}
        <div className={styles.allocations_info}>
          <div className={styles.allocations_info_left}>
            <div className={styles.allocations_info_section}>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                }}
              >
                <label>calculation type</label> &nbsp;
                <FaInfoCircle color="gray" />
              </div>
              <div>
                <span>Completes</span> &nbsp;
                <span style={{ color: "blue" }}>edit</span>
              </div>
            </div>
            <div className={styles.allocations_info_section}>
              <label>quota</label> &nbsp;
              <span>{survey?.no_of_completes}</span>
            </div>
            <div className={styles.allocations_info_section}>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                }}
              >
                <label>field end date</label>&nbsp;
                <FaInfoCircle color="gray" />
              </div>
              <span>-</span>
            </div>
            <div className={styles.allocations_info_section}>
              <label>completes</label>&nbsp;
              <span>0</span>
            </div>
            <div className={styles.allocations_info_section}>
              <label>conversion</label>&nbsp;
              <span>0%</span>
            </div>
            <div className={styles.allocations_info_section}>
              <label>survey cpi</label>&nbsp;
              <span>$ 0.50</span>
            </div>
          </div>
        </div>
        <div className={styles.external_supply_sources}>
          <div className={styles.top}>
            <p className={styles.title}>External Supply Sources</p>

            <button
              className={styles.add_supplier_btn}
              onClick={() => setSupplierModal(true)}
            >
              <AiOutlinePlusCircle size={25} /> &nbsp; Add Supplier
            </button>
          </div>
          <div style={{ overflow: "auto" }}>
            <table className={styles.external_supply_sources_table}>
              <thead>
                <tr>
                  <th>
                    Supplier <BiChevronDown />
                  </th>
                  <th>
                    TCPI <BiChevronDown />
                  </th>
                  <th>
                    Last Complete Date <BiChevronDown />
                  </th>
                  <th>
                    Allocation <BiChevronDown />
                  </th>
                  <th>
                    Prescreens <BiChevronDown />
                  </th>
                  <th>
                    Completes <BiChevronDown />
                  </th>
                  <th>
                    Allocation Remaining <BiChevronDown />
                  </th>
                  <th>
                    Total Remaining <BiChevronDown />
                  </th>
                  <th>
                    Conversion <BiChevronDown />
                  </th>
                  <th>
                    Block Optimzer <BiChevronDown />
                  </th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {externalSuppliers?.map((supplier) => {
                  return (
                    <tr key={uuid()}>
                      <td>{supplier?.supplier_account}</td>
                      <td>{supplier?.tcpi}</td>
                      <td></td>
                      <td>{supplier?.allocation?.number}</td>
                      <td>0</td>
                      <td>0</td>
                      <td>0</td>
                      <td>0</td>
                      <td>0</td>
                      <td>0%</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Internale supply source  */}
        <div className={styles.external_supply_sources}>
          <div className={styles.top}>
            <p className={styles.title}>Internal Supply Sources</p>

            {internalSuppliers?.length ? (
              <button
                className={styles.add_supplier_btn}
                onClick={handleInternalSupplierModal}
              >
                <AiOutlinePlusCircle size={25} /> &nbsp; Add Internal Supply
              </button>
            ) : (
              <button
                className={styles.add_supplier_btn}
                onClick={handleInternalSupplierModal}
              >
                <AiOutlinePlusCircle size={25} /> &nbsp; Add Internal Supply
              </button>
            )}
          </div>
          <div style={{ overflow: "auto" }}>
            <table className={styles.external_supply_sources_table}>
              <thead>
                <tr>
                  <th>
                    Supplier <BiChevronDown />
                  </th>
                  <th>
                    TCPI <BiChevronDown />
                  </th>
                  <th>
                    Last Complete Date <BiChevronDown />
                  </th>
                  <th>
                    Allocation <BiChevronDown />
                  </th>
                  <th>
                    Prescreens <BiChevronDown />
                  </th>
                  <th>
                    Completes <BiChevronDown />
                  </th>
                  <th>
                    Allocation Remaining <BiChevronDown />
                  </th>
                  <th>
                    Total Remaining <BiChevronDown />
                  </th>
                  <th>
                    Conversion <BiChevronDown />
                  </th>
                  <th>
                    Block Optimzer <BiChevronDown />
                  </th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {internalSuppliers?.map((supplier) => {
                  return (
                    <tr key={uuid()}>
                      <td>{supplier?.supplier_account}</td>
                      <td>{supplier?.tcpi}</td>
                      <td></td>
                      <td>{supplier?.allocation?.number}</td>
                      <td>0</td>
                      <td>0</td>
                      <td>0</td>
                      <td>0</td>
                      <td>0</td>
                      <td>0%</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* add external supplier modal  */}
      {supplierModal && <AddSupplierModal />}

      {/* add internal supplier modal  */}
      {internalsupplierModal && <InternalSupplierModal />}

      {/* global redirects modal  */}
      <AddStaticRedirectsModal
        addStaticRedirectsModal={staticRedirectsModal}
        setAddStaticRedirectsModal={setStaticRedirectsModal}
      />

      {/* snackbar  */}
      <SnackbarMsg
        msg={snackbarData?.msg}
        severity={snackbarData?.severity}
        open={openSnackbar}
        handleClose={handleSnackbar}
      />
    </>
  );
};

// const AddSupplierModal = () => {

// };

export default Allocations;
