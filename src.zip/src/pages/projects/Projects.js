import Header from "../../components/header/Header";
import {
  Link,
  useHistory,
  useLocation,
} from "react-router-dom/cjs/react-router-dom.min";
import { MdEdit } from "react-icons/md";
import { MdContentCopy } from "react-icons/md";
import { FiDownload } from "react-icons/fi";
import "./Projects.css";
import { useEffect, useState } from "react";
import Subheader from "../../components/subheader/Subheader";
import { useProjectContext } from "./ProjectContext";
import Hashids from "hashids";
import styles from "./Project.module.css";
import { AiOutlineSearch } from "react-icons/ai";
import facewithmask from "../../assets/images/facewithmask.png";
import { Switch } from "@nextui-org/react";
import { getAvgCPI } from "../survey-dashboard/SurveyDashboardContext";
import {
  studyTypesData,
  surveyTypesData,
  projectManagersData,
} from "../../utils/commonData";
import countryList from "react-select-country-list";
import { useMemo } from "react";
import Select from "react-select";
import { default as Muiselect } from "@mui/material/Select";
import { FormControl, InputLabel, MenuItem } from "@mui/material";
import { DateRangePicker } from "rsuite";
import { addDays, subDays } from "date-fns";

const selectCountryStyle = {
  menu: (provided, state) => ({
    ...provided,
    width: "100%",
    color: state.selectProps.menuColor,
    padding: "20px",
    zIndex: "999",
  }),
  control: (styles) => ({
    ...styles,
    width: "95%",
    border: "1px solid lightgray",
    boxShadow: "0px 4px 4px 0px rgba(0, 0, 0, 0.25)",
    margin: "0.5rem 0.5rem",
  }),
  input: (styles) => ({
    ...styles,
    height: "2.8rem",
    width: "95%",
  }),
};

const Projects = () => {
  const [countCheckedProjects, setCountCheckProjects] = useState(0);
  const [checkRows, setCheckRows] = useState([]);
  const [filters, setFilters] = useState({});
  const location = useLocation();
  const history = useHistory();
  const view = new URLSearchParams(location.search).get("view");
  const [statusesCnt, setStatusesCnt] = useState({});
  const [surveys, setSurveys] = useState([]);
  const { projects, clients } = useProjectContext();
  const countries = useMemo(() => countryList().getData(), []);

  useEffect(() => {
    setSurveys(projects);
    let tmp = {};
    projects.map((project) => {
      tmp[project?.status] =
        (tmp?.[project?.status] ? tmp?.[project?.status] : 0) + 1;
    });
    Object.keys(tmp).map((key) => {
      tmp["all"] = (tmp["all"] ? tmp["all"] : 0) + tmp[key];
    });
    setStatusesCnt(tmp);

    changedFilters();
  }, [projects]);

  useEffect(() => {
    changedFilters();
  }, [view]);

  const changedFilters = () => {
    if (view !== "all") {
      setSurveys(projects);
      filterByStatus(view);
      filterSurveys();
    } else {
      setSurveys(projects);
      filterSurveys();
    }
  };

  const handleSelect = (e) => {
    if (e.target.checked) {
      setCountCheckProjects(countCheckedProjects + 1);
      setCheckRows([...checkRows, e.target.name]);
    } else {
      setCountCheckProjects(countCheckedProjects - 1);
      setCheckRows((checkRows) => {
        return checkRows.filter((row) => row != e.target.name);
      });
    }
  };

  useEffect(() => {
    document.querySelectorAll("tr").forEach((tr) => {
      const first_cell = tr.querySelector("td");
      if (
        checkRows?.includes(
          first_cell?.querySelector("input").getAttribute("name")
        )
      ) {
        tr.style.backgroundColor = "rgb(222, 222, 230)";
      } else {
        tr.style.backgroundColor = "";
      }
    });
  }, [checkRows]);

  //seting the surveys after filter is apply
  useEffect(() => {
    setSurveys(projects);
    filterSurveys();
  }, [filters]);

  const filterByStatus = (view) => {
    setSurveys((prevData) => {
      console.log("filtering status");
      return prevData.filter((survey) => {
        if (survey.status === view) return survey;
      });
    });
  };

  const filterSurveys = () => {
    Object.keys(filters).forEach((key) => {
      if (key === "study_type" || key === "survey_type") {
        setSurveys((prevData) => {
          return prevData.filter((survey) => {
            if (survey?.[key] === filters[key]) return survey;
          });
        });
      } else if (key === "lead_pm") {
        setSurveys((prevData) => {
          return prevData.filter((survey) => {
            if (
              survey?.mirats_insights_team?.lead_project_managers.includes(
                filters[key]
              )
            )
              return survey;
          });
        });
      } else if (key === "country") {
        setSurveys((prevData) => {
          return prevData.filter((survey) => {
            if (survey?.country?.country === filters[key]?.value) return survey;
          });
        });
      } else if (key === "client") {
        setSurveys((prevData) => {
          return prevData.filter((survey) => {
            if (survey?.client_info?.client_name === filters[key])
              return survey;
          });
        });
      }
    });
  };

  console.log(clients);

  return (
    <>
      <Header />

      <div className={styles.projectWrapper}>
        <div className={styles.projectHead}>
          <div className={styles.left}>
            <div className={styles.left_header}>
              <div className={styles.head}>
                <p className={styles.p}>Surveys</p>
                <Switch />
              </div>

              <div className="searchField">
                {/* Search bar comes here  */}
                <input
                  type="search"
                  placeholder="Search Project, Surveys and much more."
                  className={styles.searchbar}
                />
                <AiOutlineSearch className="searchIcon" />
              </div>
            </div>
            <div className={styles.left_select_container}>
              {/* project managers  */}
              <FormControl fullWidth className={styles.select_input}>
                <InputLabel id="demo-simple-select-label">
                  Project Managers
                </InputLabel>
                <Muiselect
                  labelId="demo-simple-select-label"
                  id="demo-simple-select"
                  label="Project Managers"
                  onChange={(e) => {
                    setFilters((prevData) => {
                      return { ...prevData, lead_pm: e.target.value };
                    });
                  }}
                >
                  {projectManagersData?.map((pm) => (
                    <MenuItem value={pm}>{pm}</MenuItem>
                  ))}
                </Muiselect>
              </FormControl>

              {/* study type  */}
              <FormControl fullWidth className={styles.select_input}>
                <InputLabel id="demo-simple-select-label">
                  Study Type
                </InputLabel>
                <Muiselect
                  labelId="demo-simple-select-label"
                  id="demo-simple-select"
                  value={filters?.study_type}
                  label="Study Type"
                  onChange={(e) =>
                    setFilters((prevData) => {
                      return { ...prevData, study_type: e.target.value };
                    })
                  }
                >
                  {studyTypesData?.map((type) => {
                    return <MenuItem value={type.label}>{type.label}</MenuItem>;
                  })}
                </Muiselect>
              </FormControl>

              {/* country  */}
              <div>
                <Select
                  styles={selectCountryStyle}
                  options={countries}
                  value={filters?.country}
                  onChange={(e) => {
                    setFilters((prevData) => {
                      return { ...prevData, country: e };
                    });
                  }}
                />
              </div>

              {/* survey type  */}
              <FormControl fullWidth className={styles.select_input}>
                <InputLabel id="demo-simple-select-label">
                  Survey Type
                </InputLabel>
                <Muiselect
                  labelId="demo-simple-select-label"
                  id="demo-simple-select"
                  value={filters?.survey_type}
                  label="Survey Type"
                  onChange={(e) =>
                    setFilters((prevData) => {
                      return { ...prevData, survey_type: e.target.value };
                    })
                  }
                >
                  {surveyTypesData?.map((surveyType) => {
                    return <MenuItem value={surveyType}>{surveyType}</MenuItem>;
                  })}
                </Muiselect>
              </FormControl>

              {/* client  */}
              <FormControl fullWidth className={styles.select_input}>
                <InputLabel id="demo-simple-select-label">Client</InputLabel>
                <Muiselect
                  labelId="demo-simple-select-label"
                  id="demo-simple-select"
                  value={filters?.client}
                  label="Client"
                  onChange={(e) => {
                    setFilters((prevData) => {
                      return { ...prevData, client: e.target.value };
                    });
                  }}
                >
                  {clients?.map((client) => (
                    <MenuItem value={client?.company_name}>
                      {client?.company_name}
                    </MenuItem>
                  ))}
                </Muiselect>
              </FormControl>

              {/* period  */}
              <DateRangePicker
                appearance="default"
                placeholder="Default"
                style={{ width: "95%", zIndex: "10", margin: ".5rem" }}
                onChange={(e) => {
                  console.log(e);
                }}
                ranges={[
                  {
                    label: "Last 7 days",
                    value: [subDays(new Date(), 6), new Date()],
                  },
                  {
                    label: "Last 1 Month",
                    value: [subDays(new Date(), 30), new Date()],
                  },
                  {
                    label: "Last 6 Month",
                    value: [subDays(new Date(), 180), new Date()],
                  },
                  {
                    label: "1 Year",
                    value: [subDays(new Date(), 365), new Date()],
                  },
                ]}
              />
              {/* <FormControl fullWidth className={styles.select_input}>
                <InputLabel id="demo-simple-select-label">Period</InputLabel>

                <Muiselect
                  labelId="demo-simple-select-label"
                  id="demo-simple-select"
                  value=""
                  label="Period"
                >
                  <MenuItem value="this-week">This Week</MenuItem>
                  <MenuItem value="this-month">This Month</MenuItem>
                  <MenuItem value="previos-month">Previous Month</MenuItem>
                  <MenuItem value="last-6-months">Previous 6 Month</MenuItem>
                  <MenuItem value="previous-1-year">Previos 1 year</MenuItem>
                </Muiselect>
              </FormControl> */}
            </div>
          </div>
          <div className={styles.right}>
            <div className={styles.id_card}>
              <div>
                <h2>Mirats Insights ID</h2>
                <p className={styles.email}>rohan.gupta@gmail.com</p>
              </div>
              <div className={styles.id_card_description}>
                <p>
                  Get access to your dashboard. Manage your work, sign-in,
                  security and much more.{" "}
                </p>
              </div>
              <img src={facewithmask} className={styles.face_withmask} />
            </div>
          </div>
          {/* <label for="switch">Toggle</label> */}
        </div>

        {/* ----------------------------------------------------------------
                                 project Heading Links  
         ----------------------------------------------------------------*/}
        <div className={styles.projectHeadingWrapper}>
          <div className="headingLinks">
            <Link
              to="/projects?view=live"
              className={view === "live" ? styles.active : null}
            >
              Live ({statusesCnt?.live ? statusesCnt?.live : 0})
            </Link>
            <Link
              to="/projects?view=awarded"
              className={view === "awarded" ? styles.active : null}
            >
              Awarded ({statusesCnt?.awarded ? statusesCnt?.awarded : 0})
            </Link>
            <Link
              to="/projects?view=paused"
              className={view === "paused" && styles.active}
            >
              Paused ({statusesCnt?.paused ? statusesCnt?.paused : 0})
            </Link>
            <Link
              to="/projects?view=completed"
              className={view === "completed" ? styles.active : null}
            >
              Completed ({statusesCnt?.completed ? statusesCnt?.completed : 0})
            </Link>
            <Link
              to="/projects?view=billed"
              className={view === "billed" ? styles.active : null}
            >
              Billed ({statusesCnt?.billed ? statusesCnt?.billed : 0})
            </Link>
            <Link
              to="/projects?view=bidding"
              className={view === "bidding" ? styles.active : null}
            >
              Bidding ({statusesCnt?.bidding ? statusesCnt?.bidding : 0})
            </Link>
            <Link
              to="/projects?view=all"
              className={view === "all" ? styles.active : null}
            >
              All ({statusesCnt?.all ? statusesCnt?.all : 0})
            </Link>
          </div>
          <div>
            <Link
              className={styles.create_new_survey_btn}
              to="/create-new-project/basic"
            >
              Create New Survey
            </Link>
          </div>
        </div>

        {/* ----------------------------------------------------------------
                                 project Table  
         ----------------------------------------------------------------*/}
        <div className="project_page">
          <div
            style={{ overflowX: "auto" }}
            className={styles.project_table_div}
          >
            <table className="project_table" id="project_table">
              <thead style={{ width: "100%" }}>
                <tr className={styles.cell_large}>
                  <th style={{ width: "370px", textAlign: "center" }}>
                    Survey Name
                    <p className="headingDescription">
                      Project No / Survey No | Client | Status
                    </p>
                  </th>
                  <th>
                    Progress
                    <p className="headingDescription">Completes/Hits</p>
                  </th>
                  <th>
                    Avg. Cost
                    <p className="headingDescription">per complete</p>
                  </th>
                  <th>
                    IR
                    <p className="headingDescription">compl./session</p>
                  </th>
                  <th>
                    LOI
                    <p className="headingDescription">avg</p>
                  </th>
                  <th>
                    PM
                    <p className="headingDescription">lead</p>
                  </th>
                  <th>
                    EPC
                    <p className="headingDescription">per click</p>
                  </th>
                  <th>
                    Study Type
                    <p className="headingDescription">Survey Type</p>
                  </th>
                  {/* <th>Country</th> */}
                  <th>
                    Launch Date
                    <p className="headingDescription">days ago</p>
                  </th>
                </tr>
              </thead>
              <tbody>
                {surveys.map((project, index) => {
                  return (
                    <tr key={index} className="dataRow">
                      <td className="project_table_first_col">
                        <input
                          type="checkbox"
                          value="Bike"
                          name={project?.survey_name}
                          id="vehicle1"
                          onChange={handleSelect}
                        />
                        <div className="coldiv">
                          <label
                            style={{
                              color: "black",
                              fontWeight: 100,
                              fontSize: "12px",
                            }}
                            htmlFor="vehicle1"
                            onClick={() =>
                              history.push(
                                `/projects/dashboard/${project?.survey_id}`
                              )
                            }
                          >
                            {project?.survey_name}
                          </label>
                          <br />
                          <div className="project_id_and_internal_status">
                            <span>
                              #{project?.survey_id} / {project.project_id}
                            </span>

                            <span className="client">Luc.id</span>

                            <span
                              style={{
                                fontSize: "10px",
                                color: "black",
                                fontWeight: "lighter",
                              }}
                              className={`survey_status_${project.internal_status} survey_status`}
                            >
                              {project.internal_status}
                            </span>
                          </div>
                        </div>
                      </td>

                      <td>
                        {/* {project?.progress} / {project?.totalSurvey} */}
                        <span className="tableValue">
                          {project?.completes} / {project?.hits}
                        </span>
                        <br />
                        <span>completes</span>
                      </td>
                      {/* <td>{project.completes}</td> */}
                      <td>
                        {/* {project.CPI} */}
                        <span className="tableValue">{getAvgCPI()}</span>
                        <br />
                        <span>US Dollar</span>
                      </td>
                      <td>
                        {/* {project.IR} */}
                        <span className="tableValue">
                          {project?.expected_incidence_rate}%
                        </span>
                        <br />
                        <span>in-field</span>
                      </td>
                      <td>
                        <span className="tableValue">
                          {project?.expected_completion_loi}
                        </span>
                        <br />
                        <span>mins</span>
                      </td>
                      <td>
                        <span className="tableValue">
                          {
                            project?.mirats_insights_team
                              ?.lead_project_managers[0]
                          }{" "}
                          <br />
                          {
                            project?.mirats_insights_team
                              ?.lead_project_managers[1]
                          }
                        </span>
                      </td>
                      <td>
                        {/* {project.EPC} */}
                        <span className="tableValue">0.35</span>
                        <br />
                        <span>US Dollar </span>
                      </td>
                      <td>
                        <span className="tableValue">
                          {project?.study_type}
                        </span>
                        <br />
                        <span>{project?.survey_type}</span>
                      </td>
                      <td>
                        <span className="tableValue">
                          {project?.creation_date?.toDate().toDateString()}
                        </span>
                        <br />
                        <span>
                          {(
                            (new Date().getTime() -
                              project?.creation_date?.toDate().getTime()) /
                            (1000 * 3600 * 24)
                          ).toFixed(0)}{" "}
                          Days ago
                        </span>
                      </td>
                    </tr>
                  );

                  //  else if (project?.status === view) {
                  //   return (
                  //     <tr key={index}>
                  //       <td className="project_table_first_col">
                  //         <input
                  //           type="checkbox"
                  //           value="Bike"
                  //           name={project?.name}
                  //           id="vehicle1"
                  //           onChange={handleSelect}
                  //         />
                  //         <div>
                  //           <label
                  //             htmlFor="vehicle1"
                  //             onClick={() =>
                  //               history.push(
                  //                 `/projects/dashboard/${project?.name}`
                  //               )
                  //             }
                  //           >
                  //             {project?.name}
                  //           </label>
                  //           <br />
                  //           <small>{project?.projectID}</small>
                  //         </div>
                  //       </td>
                  //       <td>
                  //         {project?.progress} / {project?.totalSurvey}
                  //         <br />
                  //         <span>completes</span>
                  //       </td>
                  //       {/* <td>
                  //         {project.completes}
                  //         <br />
                  //         <span>completes</span>
                  //       </td> */}
                  //       <td>{project.CPI}</td>
                  //       <td>{project.IR}</td>
                  //       <td>{project.LOI}</td>
                  //       <td>{project.PM}</td>
                  //       <td>{project.EPC}</td>
                  //       <td>{project.study_type}</td>
                  //       <td>{project.creation_date}</td>
                  //     </tr>
                  //   );
                  // }
                })}
              </tbody>
            </table>
          </div>

          {countCheckedProjects ? (
            <div className="selected_project_op">
              <p>
                <span>{countCheckedProjects}</span> &nbsp; SURVEYS SELECTED
              </p>
              <button>
                <MdEdit color="blue" size={20} /> &nbsp; Edit
              </button>
              <button>
                <MdContentCopy color="blue" size={20} /> &nbsp; Copy IDs
              </button>
              <button>
                <FiDownload color="blue" size={20} /> &nbsp; Export CSV
              </button>
              <button>
                <FiDownload color="blue" size={20} /> &nbsp; Get Cost Summary
              </button>
            </div>
          ) : null}
        </div>
      </div>
    </>
  );
};

export default Projects;
