import React from "react";
import styles from "./card.module.css";
import { useHistory } from "react-router-dom";
function Card({ data }) {
  console.log(data);
  const history = useHistory();
  return (
    <>
      <div className={styles.card}>
        <p className={styles.title}>{data.title}</p>
        {data?.card_links.map((links) => {
          if (!links?.status) {
            return (
              <button
                className={styles.source_btn}
                onClick={() => {
                  history.push(`${links.link}`);
                }}
              >
                {links?.name}
              </button>
            );
          }
          return (
            <select className={styles.status_select}>
              {links?.status.map((link) => {
                return <option>{link}</option>;
              })}
            </select>
          );
        })}
      </div>
    </>
  );
}

export default Card;
