import React from "react";
import Header from "../../components/header/Header";
import Subheader from "../../components/subheader/Subheader";
import { useParams } from "react-router-dom";
import SurveyInfo from "../../components/survey-info/SurveyInfo";
import styles from "./sources.module.css";
import Card from "./components/Card";
function Sources() {
  let cards_data = [
    {
      title: "Cint AB",
      card_links: [
        { link: "/modifyredirects", name: "Modify Redirects" },
        { link: "/viewlink", name: "View Link" },
        { link: "/viewstats", name: "View Stats" },
        { status: ["Live", "Paused", "Awarded"] },
        { link: "/viewlivelog", name: "View Live Log" },
        { link: "/viewtestlog", name: "View Test Log" },
      ],
    },
    {
      title: "Samplico",
      card_links: [
        { link: "/modifyredirects", name: "Modify Redirects" },
        { link: "/viewlink", name: "View Link" },
        { link: "/viewstats", name: "View Stats" },
        { status: ["Live", "Paused", "Awarded"] },
        { link: "/viewlivelog", name: "View Live Log" },
        { link: "/viewtestlog", name: "View Test Log" },
      ],
    },
    {
      title: "Prodege",
      card_links: [
        { link: "/modifyredirects", name: "Modify Redirects" },
        { link: "/viewlink", name: "View Link" },
        { link: "/viewstats", name: "View Stats" },
        { status: ["Live", "Paused", "Awarded"] },
        { link: "/viewlivelog", name: "View Live Log" },
        { link: "/viewtestlog", name: "View Test Log" },
      ],
    },
    {
      title: "Cint AB",
      card_links: [
        { link: "/modifyredirects", name: "Modify Redirects" },
        { link: "/viewlink", name: "View Link" },
        { link: "/viewstats", name: "View Stats" },
        { status: ["Live", "Paused", "Awarded"] },
        { link: "/viewlivelog", name: "View Live Log" },
        { link: "/viewtestlog", name: "View Test Log" },
      ],
    },
    {
      title: "Samplico",
      card_links: [
        { link: "/modifyredirects", name: "Modify Redirects" },
        { link: "/viewlink", name: "View Link" },
        { link: "/viewstats", name: "View Stats" },
        { status: ["Live", "Paused", "Awarded"] },
        { link: "/viewlivelog", name: "View Live Log" },
        { link: "/viewtestlog", name: "View Test Log" },
      ],
    },
    {
      title: "Prodege",
      card_links: [
        { link: "/modifyredirects", name: "Modify Redirects" },
        { link: "/viewlink", name: "View Link" },
        { link: "/viewstats", name: "View Stats" },
        { status: ["Live", "Paused", "Awarded"] },
        { link: "/viewlivelog", name: "View Live Log" },
        { link: "/viewtestlog", name: "View Test Log" },
      ],
    },
    {
      title: "Cint AB",
      card_links: [
        { link: "/modifyredirects", name: "Modify Redirects" },
        { link: "/viewlink", name: "View Link" },
        { link: "/viewstats", name: "View Stats" },
        { status: ["Live", "Paused", "Awarded"] },
        { link: "/viewlivelog", name: "View Live Log" },
        { link: "/viewtestlog", name: "View Test Log" },
      ],
    },
    {
      title: "Samplico",
      card_links: [
        { link: "/modifyredirects", name: "Modify Redirects" },
        { link: "/viewlink", name: "View Link" },
        { link: "/viewstats", name: "View Stats" },
        { status: ["Live", "Paused", "Awarded"] },
        { link: "/viewlivelog", name: "View Live Log" },
        { link: "/viewtestlog", name: "View Test Log" },
      ],
    },
    {
      title: "Prodege",
      card_links: [
        { link: "/modifyredirects", name: "Modify Redirects" },
        { link: "/viewlink", name: "View Link" },
        { link: "/viewstats", name: "View Stats" },
        { status: ["Live", "Paused", "Awarded"] },
        { link: "/viewlivelog", name: "View Live Log" },
        { link: "/viewtestlog", name: "View Test Log" },
      ],
    },
    {
      title: "Cint AB",
      card_links: [
        { link: "/modifyredirects", name: "Modify Redirects" },
        { link: "/viewlink", name: "View Link" },
        { link: "/viewstats", name: "View Stats" },
        { status: ["Live", "Paused", "Awarded"] },
        { link: "/viewlivelog", name: "View Live Log" },
        { link: "/viewtestlog", name: "View Test Log" },
      ],
    },
  ];

  return (
    <>
      <Header />
      <Subheader />
      <SurveyInfo />
      <div className={styles.container}>
        <h1 className={styles.title}>Panel Sources And Traffic Channels</h1>
        <div className={styles.cards_container}>
          {cards_data.map((data) => {
            console.log(data);
            return (
              <div className={styles.single_card}>
                <Card data={data} />
              </div>
            );
          })}
        </div>
      </div>
    </>
  );
}

export default Sources;
