import React from "react";
import styles from "./livesurveylogs.module.css";
import Header from "../../components/header/Header";
import Subheader from "../../components/subheader/Subheader";
import SurveyInfo from "../../components/survey-info/SurveyInfo";

function LiveSurveyLogs() {
  return (
    <>
      <Header />
      <Subheader />
      <SurveyInfo />
      <div className={styles.container}>
        {/* Left container  */}
        <div className={styles.left_container}>
          <h1 className={styles.title}>Live Survey Logs</h1>
          <div className={styles.filters_attendancelog_container}>
            <h1 className={styles.filter_title}>Filters for Attendance Log</h1>

            <div className={styles.filtercontainer}>
              <div className={styles.filtercard}>
                <p className={styles.card_title}>Date</p>
                <select className={styles.card_select}>
                  <option value="">This Month</option>
                  <option value="">Previous Month</option>
                </select>
              </div>
              <div className={styles.filtercard}>
                <p className={styles.card_title}>Mirats Status</p>
                <select className={styles.card_select}>
                  <option value="">In Client Survey</option>
                  <option value="">Previous Month</option>
                </select>
              </div>
              <div className={styles.filtercard}>
                <p className={styles.card_title}>Client Status</p>
                <select className={styles.card_select}>
                  <option value="">Completed</option>
                  <option value="">Terminated</option>
                </select>
              </div>
              <div className={styles.filtercard}>
                <p className={styles.card_title}>Fingerprint Match</p>
                <select className={styles.card_select}>
                  <option value="">true</option>
                  <option value="">false</option>
                </select>
              </div>
            </div>
            <div className={styles.filtercontainer}>
              <div className={styles.filtercard}>
                <p className={styles.card_title}>Browser</p>
                <input
                  type="text"
                  name=""
                  className={styles.card_text}
                  id=""
                  value="Google chrome"
                />
              </div>
              <div className={styles.filtercard}>
                <p className={styles.card_title}>OS</p>
                <input
                  type="text"
                  name=""
                  className={styles.card_text}
                  id=""
                  value="Windows 11"
                />
              </div>
            </div>
          </div>
        </div>
        {/* Right Container  */}
        <div className={styles.right_container}>
          <button className={styles.download_logbtn}>Download Logs</button>
        </div>
      </div>
    </>
  );
}

export default LiveSurveyLogs;
